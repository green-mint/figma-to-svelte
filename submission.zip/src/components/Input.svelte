<script>
  export let params = {}
</script>

<input type="text" class="px-5 py-4 placeholder:uppercase placeholder:text-white bg-[#FDEAE11A] bg-opacity-10 rounded-lg" {...params}>