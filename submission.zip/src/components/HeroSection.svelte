<div>
	<!-- <h1 class="w-1/2 text-5xl font-semibold w-1/2 align-center justify-center">La chaleur que votre foyer mérite.</h1> -->
	<img src="/images/content/heropic.png" class="rounded-[12px] w-auto mx-auto mt-4" alt="" />
</div>