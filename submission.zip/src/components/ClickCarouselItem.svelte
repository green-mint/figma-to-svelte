<div class="w-4/5 px-8">
	<div class="w-full mx-auto text-center">
		<span class="opacity-70">Ils vous en parlent mieux que nous</span>
		<h1 class="text-[1.9rem] my-10 leading-tight">
			« Très bon travail, très professionnel et à l'écoute. La satisfaction du client est leur
			priorité. Chantier propre, travail soigné et très respectueux. Je recommande à 200%. »
		</h1>
    <span class="font-holy text-3xl opacity-70">Sandrine Ferreira</span>
	</div>
</div>
