<button class="rounded-full px-5 py-3 bg-accent hover:text-accent hover:bg-darkprimary group">
  <slot>Button</slot>
</button>