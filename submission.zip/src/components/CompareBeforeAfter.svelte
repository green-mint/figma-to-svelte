<script>
	import SvelteImageCompare from 'svelte-image-compare';

	// import from library
	// import ImageCompare from 'svelte-image-compare';
</script>

<SvelteImageCompare
    before="//placehold.it/600x200/E8117F/FFFFFF"
    after="//placehold.it/600x200/CCCCCC/FFFFFF"
    contain={true}
>
</SvelteImageCompare>
