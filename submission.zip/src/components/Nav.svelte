<script>
</script>

<nav style="position: sticky;" class="flex pt-6 top-0 justify-between mx-auto w-full px-4">
	<div class="logo">
		<img src="/images/content/Framelogo.svg" class="-mb-5" alt="" />
		<div class="ml-6 text-4xl font-holy text-orange-400 ">magasin</div>
	</div>
	<div class="links">
		<ul class="flex w-full space-x-6 bg-white rounded-2xl py-2 px-6">
			<li><a href="#">Nos poeles</a></li>
			<li><a href="#">La marque Turbofonte</a></li>
			<li><a href="#">Nos conseils</a></li>
			<li><a href="#">Le magasin</a></li>
			<li class="relative"><a href="#">Prendre rendez-vous <div class="h-1.5 w-1.5 rounded-full absolute bg-green-600 -right-2 top-0"/> </a></li>
		</ul>
	</div>

	<div class="text-sm space-x-2 mt-2">
		<a href="#">Support</a>
		<a href="#">Espace client</a>
	</div>
</nav>
