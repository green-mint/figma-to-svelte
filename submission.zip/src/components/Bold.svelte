<strong class="font-semibold text-darkprimary group-hover:text-accent">
  <slot>bold</slot>
</strong>